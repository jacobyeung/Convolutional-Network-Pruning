#!/bin/bash

curl http://cs231n.stanford.edu/tiny-imagenet-200.zip -O tiny-imagenet-200.zip
unzip tiny-imagenet-200.zip